#bin/bash!
export FLASK_APP=flaskapp.py
flask run