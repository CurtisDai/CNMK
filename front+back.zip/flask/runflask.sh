#!/bin/bash
nohup python3 flaskapp.py &