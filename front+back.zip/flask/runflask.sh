#bin/bash!
export FLASK_APP=flaskapp.py
flask run --host=0.0.0.0 &