<template>
    <div class="background">
        <div class ="header">
          <vs-button color="dark" icon="menu" to="/analysis"></vs-button>
          <vs-button color="dark" icon="public" to="/map1" style="float:right"></vs-button>
        </div>
        <div class="container" style="text-align:center; height: 100%;">
            <p class="font1">Author<p>
            <p class="font2">Xiaoshu Chen</p>
            <p class="font2">Tengsheng Ho</p>
            <p class="font2">Zhaoqian Dai</p>
            <p class="font2">Leungsuwan Nathaphol</p>
        </div>

    </div>
</template>
<script>
</script>
<style>
.header{
height:35px;
background-image: url("../assets/images/7S_Skulls.jpg");
background-size: 15%, 100%;
}
.background{
background-color:#06010C;
background-repeat: no-repeat;
background-position: center;
background-size: cover;
height:900px
}
.font1{
font-size:50px;
color: white
}
.font2{
font-size:35px;
color: white
}
</style>
