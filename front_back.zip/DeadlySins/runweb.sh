#!/bin/bash
nohup npm run dev &